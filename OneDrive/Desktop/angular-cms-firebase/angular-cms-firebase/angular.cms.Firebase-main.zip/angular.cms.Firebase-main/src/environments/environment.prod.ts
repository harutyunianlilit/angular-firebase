export const environment = {
  firebase: {
    projectId: 'cms-database-534d2',
    appId: '1:431544941754:web:fd5245a5d7dd9274561683',
    databaseURL: 'https://cms-database-534d2-default-rtdb.firebaseio.com',
    storageBucket: 'cms-database-534d2.appspot.com',
    apiKey: 'AIzaSyDGzdVlONxQc4ulMR7ZUCNRdHyTUB7zIOc',
    authDomain: 'cms-database-534d2.firebaseapp.com',
    messagingSenderId: '431544941754',
    measurementId: 'G-C6BQEZFVCL',
  },
  production: true
};
